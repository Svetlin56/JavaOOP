import java.util.Arrays;
import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        String[] token = scanner.nextLine().split("\\s+");

        double pricePerDay = Double.parseDouble(token[0]);
        int days = Integer.parseInt(token[1]);
        String season = token[2];
        String discountType = token[3];

        PriceCalculator calculator = new PriceCalculator(pricePerDay,days,season,discountType);
        System.out.printf("%.2f", calculator.calculatePrice());
    }
}